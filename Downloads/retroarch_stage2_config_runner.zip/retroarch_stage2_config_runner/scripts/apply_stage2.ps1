param(
    [string]$ProjectRoot = "g:\VSC projects\gameplay-automation-retroarch"
)

$ErrorActionPreference = "Stop"

$SourceRoot = Split-Path -Parent $PSScriptRoot

$Files = @(
    @{ Source = "README.md"; Destination = "README.md" },
    @{ Source = "requirements.txt"; Destination = "requirements.txt" },
    @{ Source = "config\default.yaml"; Destination = "config\default.yaml" },
    @{ Source = "src\scenarios\scripted_playback.py"; Destination = "src\scenarios\scripted_playback.py" }
)

$BackupRoot = Join-Path $ProjectRoot ("backups\stage2-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null

foreach ($File in $Files) {
    $src = Join-Path $SourceRoot $File.Source
    $dst = Join-Path $ProjectRoot $File.Destination
    $dstDir = Split-Path -Parent $dst
    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null

    if (Test-Path $dst) {
        $backupDst = Join-Path $BackupRoot $File.Destination
        $backupDir = Split-Path -Parent $backupDst
        New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
        Copy-Item $dst $backupDst -Force
    }

    Copy-Item $src $dst -Force
    Write-Host "Updated $dst"
}

Write-Host "Backup saved to $BackupRoot"
Write-Host "Now run: pip install -r requirements.txt"
Write-Host "Then run: python \"$ProjectRoot\src\scenarios\scripted_playback.py\""
