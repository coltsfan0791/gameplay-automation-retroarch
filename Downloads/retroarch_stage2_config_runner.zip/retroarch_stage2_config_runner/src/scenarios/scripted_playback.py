from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Enable direct script execution from the scenarios folder.
SRC_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from core.interfaces import ActionEvent
from core.scheduler import FrameScheduler
from input.vgamepad_backend import VGamepadBackend


DEFAULT_SEQUENCE: list[ActionEvent] = [
    ActionEvent("a", hold_seconds=0.08),
    ActionEvent("right", hold_seconds=0.10),
    ActionEvent("b", hold_seconds=0.08),
    ActionEvent("left", hold_seconds=0.10),
    ActionEvent("y", hold_seconds=0.08),
]


def _load_yaml_module():
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError("PyYAML is required. Install with: pip install pyyaml") from exc
    return yaml


def _load_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        print(f"Config not found: {config_path}. Using built-in fallback sequence.")
        return {}

    yaml = _load_yaml_module()
    with config_path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle) or {}

    if not isinstance(loaded, dict):
        raise ValueError(f"Config root must be a mapping/object: {config_path}")

    return loaded


def _section(config: dict[str, Any], name: str) -> dict[str, Any]:
    value = config.get(name, {})
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"Config section '{name}' must be a mapping/object.")
    return value


def _runtime_target_fps(config: dict[str, Any]) -> int:
    runtime = _section(config, "runtime")
    raw_fps = runtime.get("target_fps", 60)
    if not isinstance(raw_fps, int):
        raise ValueError("runtime.target_fps must be an integer.")
    if raw_fps <= 0:
        raise ValueError("runtime.target_fps must be positive.")
    return raw_fps


def _build_sequence(config: dict[str, Any]) -> list[ActionEvent]:
    playback = _section(config, "playback")

    if "sequence" not in playback:
        print("playback.sequence missing. Using built-in fallback demo sequence.")
        return list(DEFAULT_SEQUENCE)

    raw_sequence = playback["sequence"]
    if not isinstance(raw_sequence, list):
        raise ValueError("playback.sequence must be a list of action entries.")

    events: list[ActionEvent] = []
    for index, entry in enumerate(raw_sequence, start=1):
        if not isinstance(entry, dict):
            raise ValueError(f"playback.sequence[{index}] must be a mapping/object.")

        action = entry.get("action")
        if not isinstance(action, str) or not action.strip():
            raise ValueError(f"playback.sequence[{index}].action must be a non-empty string.")

        hold_seconds = entry.get("hold_seconds", 0.05)
        if not isinstance(hold_seconds, (int, float)):
            raise ValueError(f"playback.sequence[{index}].hold_seconds must be a number.")
        if hold_seconds < 0:
            raise ValueError(f"playback.sequence[{index}].hold_seconds cannot be negative.")

        events.append(ActionEvent(action.strip(), hold_seconds=float(hold_seconds)))

    return events


def _log_path(config: dict[str, Any]) -> Path | None:
    logging_cfg = _section(config, "logging")

    if logging_cfg.get("enabled", True) is False:
        return None

    folder_raw = logging_cfg.get("folder", "logs")
    prefix_raw = logging_cfg.get("file_prefix", "playback")

    if not isinstance(folder_raw, str) or not folder_raw.strip():
        raise ValueError("logging.folder must be a non-empty string.")
    if not isinstance(prefix_raw, str) or not prefix_raw.strip():
        raise ValueError("logging.file_prefix must be a non-empty string.")

    folder = Path(folder_raw)
    if not folder.is_absolute():
        folder = PROJECT_ROOT / folder

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return folder / f"{prefix_raw}-{stamp}.jsonl"


def _build_backend(config: dict[str, Any]) -> VGamepadBackend:
    input_cfg = _section(config, "input")
    backend_name = input_cfg.get("backend", "vgamepad")

    if backend_name != "vgamepad":
        raise ValueError(
            f"Unsupported input.backend '{backend_name}'. "
            "Stage 2 currently supports only 'vgamepad'."
        )

    return VGamepadBackend()


def main() -> None:
    config_path = PROJECT_ROOT / "config" / "default.yaml"
    config = _load_config(config_path)

    backend = _build_backend(config)
    log_file = _log_path(config)
    scheduler = FrameScheduler(
        backend=backend,
        target_fps=_runtime_target_fps(config),
        log_file=log_file,
    )
    events = _build_sequence(config)

    print(f"Loaded {len(events)} event(s) from: {config_path}")
    scheduler.run(events)

    if log_file is None:
        print("Playback complete. Logging disabled.")
    else:
        print(f"Playback complete. Log: {log_file}")


if __name__ == "__main__":
    main()
