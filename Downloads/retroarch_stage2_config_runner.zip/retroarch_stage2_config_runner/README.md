# Gameplay Automation - RetroArch

This folder contains a staged automation framework for controlling RetroArch externally.

## Architecture

- `src/core/interfaces.py`: shared contracts for input adapters and perception adapters.
- `src/core/scheduler.py`: deterministic frame-timed control loop.
- `src/input/vgamepad_backend.py`: Windows virtual gamepad backend using `vgamepad`.
- `src/scenarios/scripted_playback.py`: YAML-driven input sequence replay runner.
- `config/default.yaml`: timing, backend, logging, mapping defaults, and macro sequence.
- `logs/`: runtime JSONL traces for validation and replay comparison.

## Design goals

- Keep platform-specific code isolated behind adapter interfaces.
- Use a monotonic scheduler for repeatable timing.
- Log all dispatched actions with timestamps for drift analysis.
- Allow simple macros to be edited from YAML without touching Python.

## Quick start

1. Install dependencies:

```powershell
pip install -r requirements.txt
```

Or install directly:

```powershell
pip install pyyaml vgamepad
```

2. Edit the macro sequence in:

```text
config/default.yaml
```

3. Run scripted playback:

```powershell
python "g:/VSC projects/gameplay-automation-retroarch/src/scenarios/scripted_playback.py"
```

4. Inspect logs in the configured logging folder. By default:

```text
logs/
```

## YAML macro format

The Stage 2 runner reads `playback.sequence` from `config/default.yaml`.

```yaml
playback:
  sequence:
    - action: a
      hold_seconds: 0.08
    - action: right
      hold_seconds: 0.10
    - action: b
      hold_seconds: 0.08
```

Each entry supports:

- `action`: button/action name, such as `a`, `b`, `x`, `y`, `up`, `down`, `left`, or `right`.
- `hold_seconds`: how long to hold the action before releasing it.

Supported actions currently depend on `src/input/vgamepad_backend.py`.

## Current supported actions

The current `VGamepadBackend` supports:

```text
a, b, x, y, up, down, left, right
```

Stage 3 should expand this to include:

```text
start, back/select, lb, rb, lt, rt, left_stick, right_stick
```

## Fallback behavior

If `playback.sequence` is missing from the config, the script uses the built-in demo sequence:

```text
a -> right -> b -> left -> y
```

Malformed config entries fail with clear errors instead of silently doing nothing.

## Safety note

Use this for your own offline/single-player RetroArch automation, testing, routing, accessibility, and macro playback. Do not use emulator automation to cheat in online games or violate game/community rules.
