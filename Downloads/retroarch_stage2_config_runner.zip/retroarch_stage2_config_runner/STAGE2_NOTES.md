# Stage 2 Notes - Config-Driven Macro Runner

## What changed

This upgrade turns `scripted_playback.py` from a hardcoded demo into a YAML-driven macro runner.

You can now edit this file:

```text
config/default.yaml
```

And change this section:

```yaml
playback:
  sequence:
    - action: a
      hold_seconds: 0.08
```

without editing Python.

## Files to replace in your project

Copy these files into your project:

```text
README.md
requirements.txt
config/default.yaml
src/scenarios/scripted_playback.py
```

Do not replace these yet:

```text
src/input/vgamepad_backend.py
src/core/interfaces.py
src/core/scheduler.py
```

Those already fit Stage 2.

## Run command

```powershell
pip install -r requirements.txt
python "g:/VSC projects/gameplay-automation-retroarch/src/scenarios/scripted_playback.py"
```

## Verification checklist

- RetroArch receives the macro inputs.
- Console prints how many events were loaded.
- A JSONL log appears in `logs/`.
- Editing `config/default.yaml` changes the macro without Python edits.

## Next upgrade

Stage 3 should expand `VGamepadBackend` to support Start, Back/Select, LB/RB, triggers, and analog stick movement.
